"""
Project-level URL configuration.

Yeh file saari URLs ko manage karti hai aur unhe respective apps mein bhejti hai.
"""

from django.contrib import admin
from django.contrib.auth import views as auth_views  # Built-in auth views
from django.urls import path, include

urlpatterns = [
    # Admin panel ki URL
    path('admin/', admin.site.urls),
    
    # Notes app ki saari URLs - notes/ se start hone wali
    path('', include('notes.urls')),
    
    # Built-in login view - Django ka ready-made login system
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    
    # Built-in logout view - Django ka ready-made logout system
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]
