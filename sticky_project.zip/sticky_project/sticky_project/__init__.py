# Sticky Project - Django Sticky Notes Application
# Yeh file Python ko batati hai ke yeh ek package hai
