"""
Django settings for sticky_project.

Yeh file project ki saari configurations rakhti hai.
"""

from pathlib import Path

# Project ka base directory - yahan se saari paths start hote hain
BASE_DIR = Path(__file__).resolve().parent.parent


# SECURITY WARNING: Production mein yeh False hona chahiye
DEBUG = True

# Production mein apna domain yahan add karo
ALLOWED_HOSTS = []


# Application definition - yeh saari apps hain jo project mein use ho rahi hain
INSTALLED_APPS = [
    # Django ki built-in apps
    'django.contrib.admin',      # Admin panel ke liye
    'django.contrib.auth',       # Authentication system ke liye
    'django.contrib.contenttypes',
    'django.contrib.sessions',   # Session management ke liye
    'django.contrib.messages',   # Messages display karne ke liye
    'django.contrib.staticfiles', # Static files (CSS, JS, images) ke liye
    
    # Humari custom app - notes
    'notes',
]

# Middleware - requests aur responses ke beech mein processing ke liye
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',  # CSRF protection
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# Root URL configuration ka path
ROOT_URLCONF = 'sticky_project.urls'

# Template settings - HTML files kahan hain aur kaise process hote hain
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],  # Global templates directory (agar ho toh)
        'APP_DIRS': True,  # Har app ke templates folder ko check karo
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# WSGI application ka path
WSGI_APPLICATION = 'sticky_project.wsgi.application'


# Database configuration - SQLite use kar rahe hain (development ke liye perfect hai)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',  # Database file ka location
    }
}


# Password validation - strong passwords enforce karne ke liye
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization settings
LANGUAGE_CODE = 'en-us'  # Default language
TIME_ZONE = 'UTC'        # Default timezone
USE_I18N = True          # Internationalization enabled
USE_TZ = True            # Timezone support enabled


# Static files (CSS, JavaScript, Images)
STATIC_URL = 'static/'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Login redirects - user login ke baad kahan jaye
LOGIN_REDIRECT_URL = '/notes/'      # Login ke baad notes page pe jao
LOGOUT_REDIRECT_URL = '/login/'     # Logout ke baad login page pe jao

# Login URL - jahan login page hai
LOGIN_URL = '/login/'
