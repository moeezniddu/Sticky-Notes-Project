"""
WSGI configuration for sticky_project.

Yeh file web servers (like Apache, Nginx) ke saath communication ke liye use hoti hai.
Production deployment ke waqt yeh file kaam aati hai.
"""

import os

from django.core.wsgi import get_wsgi_application

# Settings module batana zaroori hai
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sticky_project.settings')

# WSGI application create karo
application = get_wsgi_application()
