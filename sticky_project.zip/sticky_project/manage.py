#!/usr/bin/env python
"""
Django ka management script - yeh project ko run karne ke liye use hota hai
"""
import os
import sys


def main():
    """Django management commands execute karne ka main function"""
    # Yeh batata hai ke settings kahan hain
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sticky_project.settings')
    
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Django install nahi hai. Please install karo: pip install django"
        ) from exc
    
    # Command line se aaye arguments execute karo
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
