"""
Views for Notes App.

Yeh file saari logic rakhti hai jo user requests ko handle karti hai.
Har view ek function hai jo HTTP request receive karta hai aur response return karta hai.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required  # Login required decorator
from django.contrib.auth import login  # User ko login karne ke liye
from django.contrib.auth.forms import UserCreationForm  # Built-in registration form
from django.contrib import messages  # Flash messages display karne ke liye
from django.db.models import Q  # Complex queries ke liye

from .models import Note  # Humara Note model
from .forms import NoteForm  # Humara Note form


def register_view(request):
    """
    New user registration handle karne ka view.
    
    GET request pe registration form dikhata hai.
    POST request pe form data process karta hai aur naya user create karta hai.
    
    Args:
        request: HTTP request object
        
    Returns:
        HttpResponse: Registration form ya redirect to notes page
    """
    # Agar user already logged in hai toh seedha notes page bhejo
    if request.user.is_authenticated:
        return redirect('note_list')
    
    # POST request - form submit hua hai
    if request.method == 'POST':
        # UserCreationForm mein POST data daalo
        form = UserCreationForm(request.POST)
        
        # Form valid hai toh user create karo
        if form.is_valid():
            user = form.save()  # User database mein save karo
            login(request, user)  # User ko automatically login kar do
            
            # Success message dikhayo
            messages.success(request, f"Welcome {user.username}! Aapka account ban gaya hai.")
            
            # Notes page pe redirect karo
            return redirect('note_list')
        else:
            # Form mein errors hain
            messages.error(request, "Registration fail hui. Errors check karo.")
    else:
        # GET request - khali form dikhayo
        form = UserCreationForm()
    
    # Registration template render karo
    return render(request, 'register.html', {'form': form})


@login_required
def note_list(request):
    """
    Logged-in user ki saari notes dikhane ka view.
    
    Yeh view user ki saari notes fetch karta hai aur list mein dikhata hai.
    Search functionality bhi support karta hai.
    
    Args:
        request: HTTP request object
        
    Returns:
        HttpResponse: Notes list template with user's notes
    """
    # Current logged-in user ki notes fetch karo
    notes = Note.objects.filter(owner=request.user)
    
    # Search functionality
    search_query = request.GET.get('q', '')  # URL se search query lo
    if search_query:
        # Title ya content mein search karo (case-insensitive)
        notes = notes.filter(
            Q(title__icontains=search_query) | 
            Q(content__icontains=search_query)
        )
    
    # Template context prepare karo
    context = {
        'notes': notes,
        'search_query': search_query,
        'total_notes': notes.count(),
    }
    
    # Notes list template render karo
    return render(request, 'note_list.html', context)


@login_required
def note_create(request):
    """
    Nayi note create karne ka view.
    
    GET request pe empty form dikhata hai.
    POST request pe form validate karke nayi note save karta hai.
    
    Args:
        request: HTTP request object
        
    Returns:
        HttpResponse: Note form ya redirect to notes list
    """
    # POST request - form submit hua hai
    if request.method == 'POST':
        # NoteForm mein POST data daalo
        form = NoteForm(request.POST)
        
        # Form valid hai toh note save karo
        if form.is_valid():
            # Pehle note object create karo lekin save mat karo (commit=False)
            # Kyunki owner set karna hai
            note = form.save(commit=False)
            
            # Current user ko owner banao
            note.owner = request.user
            
            # Ab note save karo
            note.save()
            
            # Success message
            messages.success(request, "Note successfully create ho gayi!")
            
            # Notes list pe redirect karo
            return redirect('note_list')
        else:
            # Form mein errors hain
            messages.error(request, "Form mein errors hain. Please check karo.")
    else:
        # GET request - khali form dikhayo
        form = NoteForm()
    
    # Context mein form aur action batao (create ke liye)
    context = {
        'form': form,
        'action': 'Create',  # Template ko batane ke liye ke create hai ya edit
    }
    
    # Note form template render karo
    return render(request, 'note_form.html', context)


@login_required
def note_edit(request, pk):
    """
    Existing note edit karne ka view.
    
    User sirf apni notes edit kar sakta hai. Kisi aur ki note access karne pe 404 aayega.
    
    Args:
        request: HTTP request object
        pk: Note ka primary key (ID)
        
    Returns:
        HttpResponse: Note form with existing data ya redirect to notes list
    """
    # Note fetch karo, agar nahi mili toh 404 error
    # get_object_or_404 automatically check karega ke note exist karti hai
    note = get_object_or_404(Note, pk=pk, owner=request.user)
    
    # POST request - form submit hua hai
    if request.method == 'POST':
        # Existing note instance ke saath form banao
        form = NoteForm(request.POST, instance=note)
        
        # Form valid hai toh changes save karo
        if form.is_valid():
            form.save()  # Changes save karo
            
            # Success message
            messages.success(request, "Note successfully update ho gayi!")
            
            # Notes list pe redirect karo
            return redirect('note_list')
        else:
            # Form mein errors hain
            messages.error(request, "Form mein errors hain. Please check karo.")
    else:
        # GET request - existing data ke saath form dikhayo
        form = NoteForm(instance=note)
    
    # Context mein form, note aur action batao
    context = {
        'form': form,
        'note': note,
        'action': 'Edit',  # Template ko batane ke liye
    }
    
    # Note form template render karo
    return render(request, 'note_form.html', context)


@login_required
def note_delete(request, pk):
    """
    Note delete karne ka view.
    
    GET request pe confirmation page dikhata hai.
    POST request pe note delete kar deta hai.
    
    Args:
        request: HTTP request object
        pk: Note ka primary key (ID)
        
    Returns:
        HttpResponse: Delete confirmation page ya redirect to notes list
    """
    # Note fetch karo, agar nahi mili toh 404 error
    # Sirf current user ki notes delete ho sakti hain
    note = get_object_or_404(Note, pk=pk, owner=request.user)
    
    # POST request - user ne confirm kar diya hai delete karna
    if request.method == 'POST':
        # Note delete karo
        note.delete()
        
        # Success message
        messages.success(request, "Note successfully delete ho gayi!")
        
        # Notes list pe redirect karo
        return redirect('note_list')
    
    # GET request - confirmation page dikhayo
    context = {
        'note': note,
    }
    
    # Delete confirmation template render karo
    return render(request, 'note_confirm_delete.html', context)
