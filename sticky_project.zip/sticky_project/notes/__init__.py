# Notes App - Sticky Notes functionality ke liye
# Yeh file Python ko batati hai ke yeh ek package hai
