"""
Admin configuration for Notes App.

Yeh file batati hai ke Note model ko admin panel mein kaise dikhana hai.
Admin panel mein data dekhne aur manage karne ke liye yeh zaroori hai.
"""

from django.contrib import admin
from .models import Note  # Humara Note model import karo


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    """
    Note model ke liye admin panel configuration.
    
    Yeh class batati hai ke admin panel mein notes kaise dikhayi denge
    aur kaunse fields filter/search ke liye available honge.
    """
    
    # List view mein kaunse columns dikhane hain
    list_display = ['title', 'owner', 'color', 'created_at', 'updated_at']
    
    # Kaunse fields ke hisaab se filter kar sakte hain
    list_filter = ['owner', 'created_at', 'color']
    
    # Kaunse fields mein search kar sakte hain
    search_fields = ['title', 'content', 'owner__username']
    
    # Kaunse fields read-only hain (user change nahi kar sakta)
    readonly_fields = ['created_at', 'updated_at']
    
    # Kitne notes per page dikhane hain
    list_per_page = 20
    
    # Date hierarchy sidebar mein dikhane ke liye
    date_hierarchy = 'created_at'
