"""
Models for Notes App.

Yeh file database structure define karti hai - kaunse tables hain aur unmein kya data store hoga.
"""

from django.db import models
from django.contrib.auth.models import User  # Django ka built-in User model


class Note(models.Model):
    """
    Note model - har ek sticky note ke liye.
    
    Yeh model ek table banayega database mein jismein saari notes store hongi.
    Har note ka apna title, content, color, timestamps aur owner hoga.
    """
    
    # Note ka title - maximum 200 characters
    title = models.CharField(
        max_length=200,
        help_text="Note ka title yahan likho"
    )
    
    # Note ka actual content - koi length limit nahi (TextField)
    content = models.TextField(
        help_text="Apna note yahan likho"
    )
    
    # Note ka background color - hex format mein (jaise #FFFF99)
    # Default color light yellow hai (typical sticky note color)
    color = models.CharField(
        max_length=7,
        default='#FFFF99',
        help_text="Note ka color hex format mein (jaise #FF5733)"
    )
    
    # Kab note create hui - auto_now_add automatically current time set karta hai
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Kab note last update hui - auto_now har save pe update karta hai
    updated_at = models.DateTimeField(auto_now=True)
    
    # Note ka owner - ForeignKey se User model se link hai
    # on_delete=models.CASCADE means agar user delete ho toh uski saari notes bhi delete
    # related_name='notes' se hum user.notes karke uski saari notes access kar sakte hain
    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='notes'
    )
    
    class Meta:
        """
        Model ke additional options yahan define hote hain.
        """
        # Notes ko updated_at ke hisaab se order karo (sabse pehle latest)
        ordering = ['-updated_at']
        
        # Admin panel mein plural name
        verbose_name_plural = 'Notes'
    
    def __str__(self):
        """
        Yeh method batata hai ke note ko string ke roop mein kaise dikhana hai.
        Admin panel aur debugging mein kaam aata hai.
        """
        return f"{self.title} - {self.owner.username}"
    
    def get_summary(self):
        """
        Note ke content ka chhota sa summary return karta hai.
        List view mein dikhane ke kaam aayega.
        """
        if len(self.content) > 100:
            return self.content[:100] + "..."
        return self.content
