"""
App configuration for Notes App.

Yeh file notes app ki configuration rakhti hai.
"""

from django.apps import AppConfig


class NotesConfig(AppConfig):
    """
    Notes app ki configuration class.
    
    Yeh class Django ko batati hai ke yeh app kaise behave karega.
    """
    
    # Default auto field type for models
    default_auto_field = 'django.db.models.BigAutoField'
    
    # App ka name - yeh app ka Python path hai
    name = 'notes'
    
    # Admin panel mein dikhane wala name
    verbose_name = 'Sticky Notes'
    
    def ready(self):
        """
        App ready hone pe yeh method call hoti hai.
        
        Yahan signals register kar sakte hain ya koi initialization code.
        """
        pass
