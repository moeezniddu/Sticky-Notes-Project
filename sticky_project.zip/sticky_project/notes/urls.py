"""
URL configuration for Notes App.

Yeh file notes app ki saari URLs define karti hai.
Har URL pattern ek specific view ko map karta hai.
"""

from django.urls import path
from . import views  # Humare saare views import karo

# URL patterns ki list - har pattern ek URL ko view se connect karta hai
urlpatterns = [
    # Home page - sabse pehle yahi dikhayi degi
    # Agar user logged in hai toh notes dikhayenge, warna redirect hoga
    path('', views.note_list, name='home'),
    
    # User registration page
    # Naye users yahan se account bana sakte hain
    path('register/', views.register_view, name='register'),
    
    # Notes list page - logged-in user ki saari notes
    # Yeh main page hai jahan saari notes grid mein dikhayi deti hain
    path('notes/', views.note_list, name='note_list'),
    
    # Nayi note create karne ka page
    # Form dikhata hai jahan user nayi note likh sakta hai
    path('notes/new/', views.note_create, name='note_create'),
    
    # Existing note edit karne ka page
    # <int:pk> note ka ID hai jo URL se milta hai
    path('notes/<int:pk>/edit/', views.note_edit, name='note_edit'),
    
    # Note delete karne ka confirmation page
    # Pehle confirmation dikhata hai, phir delete karta hai
    path('notes/<int:pk>/delete/', views.note_delete, name='note_delete'),
]
