"""
Forms for Notes App.

Yeh file HTML forms define karti hai jo user se data collect karte hain.
ModelForm use karne se form automatically model ke structure se ban jata hai.
"""

from django import forms
from .models import Note  # Humara Note model


class NoteForm(forms.ModelForm):
    """
    Note create aur update karne ke liye form.
    
    Yeh form user se title, content aur color collect karta hai.
    Owner aur timestamps automatically set hote hain, isliye yahan nahi hain.
    """
    
    # Color field ko color picker input type banana
    # widget=forms.TextInput(attrs={'type': 'color'}) se browser ka color picker use hoga
    color = forms.CharField(
        widget=forms.TextInput(attrs={
            'type': 'color',  # HTML5 color input
            'class': 'form-control-color',  # CSS class styling ke liye
        }),
        help_text="Apne note ke liye color choose karo",
        initial='#FFFF99'  # Default light yellow
    )
    
    class Meta:
        """
        Form ke meta options - kaunsa model aur kaunse fields use karne hain.
        """
        # Yeh form Note model ke liye hai
        model = Note
        
        # Sirf yeh 3 fields user ko dikhane hain
        # owner, created_at, updated_at automatically handle honge
        fields = ['title', 'content', 'color']
        
        # Har field ke liye widgets customize kar rahe hain
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',  # Bootstrap styling
                'placeholder': 'Note ka title likho...',
                'maxlength': '200',
            }),
            'content': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Apna note yahan likho...',
                'rows': 6,  # Textarea ki height
            }),
        }
        
        # Help text har field ke liye
        help_texts = {
            'title': 'Maximum 200 characters allowed hain.',
            'content': 'Jo bhi yaad rakhna hai woh yahan likho.',
        }
    
    def clean_title(self):
        """
        Title field ko validate karne ka custom method.
        
        Yeh check karega ke title khali toh nahi hai.
        """
        title = self.cleaned_data.get('title')
        
        # Title khali na ho
        if not title or title.strip() == '':
            raise forms.ValidationError("Title khali nahi ho sakta!")
        
        return title.strip()  # Extra spaces hata do
    
    def clean_content(self):
        """
        Content field ko validate karne ka custom method.
        
        Yeh check karega ke content khali toh nahi hai.
        """
        content = self.cleaned_data.get('content')
        
        # Content khali na ho
        if not content or content.strip() == '':
            raise forms.ValidationError("Content khali nahi ho sakta!")
        
        return content.strip()
